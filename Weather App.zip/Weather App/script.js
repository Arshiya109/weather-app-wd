let celsius = true;

function setWeatherBackground(condition) {
  const animationContainer = document.getElementById("weather-animation");

  let animationFile = "";

  if (condition.includes("cloud")) {
    animationFile = "https://assets10.lottiefiles.com/packages/lf20_jmBauI.json"; // overcast clouds
  } else if (condition.includes("rain")) {
    animationFile = "https://assets2.lottiefiles.com/packages/lf20_jmBauI.json"; // rain
  } else if (condition.includes("clear")) {
    animationFile = "https://assets2.lottiefiles.com/packages/lf20_HpFqiS.json"; // sunny
  } else if (condition.includes("snow")) {
    animationFile = "https://assets7.lottiefiles.com/packages/lf20_pTz4Jk.json"; // snow
  } else {
    animationFile = "https://assets2.lottiefiles.com/packages/lf20_jmBauI.json"; // default
  }

  // Clear previous animation
  animationContainer.innerHTML = "";

  lottie.loadAnimation({
    container: animationContainer,
    renderer: "svg",
    loop: true,
    autoplay: true,
    path: animationFile,
  });
}


function toggleTemp() {
  const temp = document.getElementById("temp");
  let value = parseFloat(temp.textContent);
  if (isNaN(value)) return;
  if (celsius) {
    value = (value * 9 / 5) + 32;
    temp.textContent = `${value.toFixed(1)}°F`;
  } else {
    value = (value - 32) * 5 / 9;
    temp.textContent = `${value.toFixed(1)}°C`;
  }
  celsius = !celsius;
  document.querySelector(".temp-toggle").textContent = celsius ? "Switch to °F" : "Switch to °C";
}

async function getWeather() {
  const city = document.getElementById("city").value;
  const apiKey = "fc5dc5585de50848008ea3e4579763ab"; 
  const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`);
    if (!response.ok) {
        alert("Error fetching weather data. Please try again.");
        return;
    }
  const data = await response.json();

  if (data.cod === 200) {
    document.getElementById("temp").textContent = `${data.main.temp}°C`;
    document.getElementById("description").textContent = data.weather[0].description;
    document.getElementById("humidity").textContent = `Humidity: ${data.main.humidity}%`;
    document.getElementById("wind").textContent = `Wind: ${data.wind.speed} km/h`;
    document.getElementById("icon").innerHTML = `<img src="http://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png">`;
    document.getElementById("uv").textContent = Math.floor(Math.random() * 10); // Simulated UV
    document.getElementById("aqi").textContent = Math.floor(Math.random() * 300); // Simulated AQI
  } else {
    alert("City not found!");
  }
  setWeatherBackground(data.weather[0].main.toLowerCase());
}